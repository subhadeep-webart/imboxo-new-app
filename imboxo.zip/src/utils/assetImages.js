export { default as AUTH_SLIDER_1 } from "@/assets/images/auth_movie_slider_image1.jpg";
export { default as AUTH_SLIDER_2 } from "@/assets/images/auth_movie_slider_image2.jpg";
