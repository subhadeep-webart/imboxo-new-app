/* ALL THE ENDPOINT LISTED HERE */
export const API_ENDPOINTS={
    LOGIN:"/login",
    SIGNUP:"/signup",
    GET_MOVIE:"/movie-list",
    GET_MOVIE_CATEGORY_WISE:"/movie-collection"
}