const CreatorSignUp=()=>{
    return(
        <>
            Creator Signup
        </>
    )
}

export default CreatorSignUp;