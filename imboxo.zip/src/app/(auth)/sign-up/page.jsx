const SignUp=()=>{
    return(
        <>
            Sign up page
        </>
    )
}

export default SignUp;