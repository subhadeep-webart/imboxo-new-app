const MovieCategoryTagBadge = ({categoryType}) => {
    return (
        <li className="each-tag">{categoryType}</li>
    )
}

export default MovieCategoryTagBadge